import { taskServcie } from "../service/service.js";

window.addEventListener("load", initEvents);
let cardDiv;
let edit;
function initEvents() {
  let addButton = document.getElementById("add");
  addButton.addEventListener("click", addTask);
  cardDiv = document.querySelector("#cards");
  edit = document.querySelector("#edit");
}

function addTask() {
  let ids = ["title", "description", "date", "priority"];
  let taskObject = {};
  for (let id of ids) {
    taskObject[id] = document.getElementById(id).value;
  }
  taskServcie.addTask(taskObject);
  printTasks();
}

function printTasks() {
  cardDiv.innerHTML = "";
  taskServcie.tasks.map((task) => printCard(task));
}

//<div class="card" style="width: 18rem;">
// <img src="..." class="card-img-top" alt="...">
// <div class="card-body">
//  <h5 class="card-title">Card title</h5>
// <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card’s content.</p>
// <a href="#" class="btn btn-primary">Go somewhere</a>
// </div>
//</div>

function deleteTask(id) {
  taskServcie.deleteTask(id);
  printTasks();
}

function editTask(id) {
  const task = taskServcie.getTaskById(id);
  let ids = ["title", "description", "date", "priority"];

  for (let id of ids) {
    document.getElementById(id).value = task[id];
  }
  edit.addEventListener("click", () => update(id));
  edit.disabled = false;
}

function update(id) {
  let ids = ["title", "description", "date", "priority"];
  let taskObject = {};
  for (let id of ids) {
    taskObject[id] = document.getElementById(id).value;
  }
  taskServcie.updateTask(taskObject, id);
  edit.disabled = true;

  printTasks();
}

function printCard(task) {
  const card = document.createElement("div");
  card.classList = "card";
  card.style.width = "18rem";
  const title = document.createElement("h3");
  title.classList = "card-title";
  title.innerText = task.title;
  const description = document.createElement("p");
  description.classList = "card-text";
  description.innerText = task.description;
  const date = document.createElement("h4");
  date.classList = "card-title";
  date.innerText = task.date;
  const priority = document.createElement("h5");
  priority.classList = "card-title";
  priority.innerText = task.priority;
  const button = document.createElement("button");
  button.classList = "btn btn-danger";
  button.innerText = "delete";
  button.onclick = () => deleteTask(task.id);
  const editButton = document.createElement("button");
  editButton.classList = "btn btn-secondary";
  editButton.innerText = "edit";
  editButton.onclick = () => editTask(task.id);
  card.append(title, description, date, priority, button, editButton);
  cardDiv.appendChild(card);
}
