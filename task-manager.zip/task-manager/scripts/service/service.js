// import Task from "../model/model";

import { Task } from "../model/model.js";

export const taskServcie = {
  tasks: [],

  addTask(taskObject) {
    const id = Math.floor(Math.random() * 1000);
    const task = new Task(
      id,
      taskObject.title,
      taskObject.description,
      taskObject.date,
      taskObject.priority
    );

    const isExist = this.getTaskById(id);
    if (!isExist) {
      this.tasks.push(task);
    } else {
      alert("Task already Exist with This id Please Press Add Again");
    }
  },

  deleteTask(id) {
    this.tasks = this.tasks.filter((task) => task.id !== id);
  },
  updateTask(taskObject, id) {
    console.log(this.tasks, taskObject);
    const index = this.tasks.findIndex((task) => task.id === id);
    const oldTask = this.getTaskById(id);
    const task = new Task(
      oldTask.id,
      taskObject.title,
      taskObject.description,
      taskObject.date,
      taskObject.priority
    );

    this.tasks.splice(index, 1, task);
  },
  getTasks() {},
  getTaskById(id) {
    const task = this.tasks.find((task) => task.id === id);
    return task;
  },
};
