export class Task {
  constructor(id, title, description, date, priority) {
    this.id = id;
    this.title = title;
    this.description = description;
    this.date = date;
    this.priority = priority;
  }
}

// export default Task;
