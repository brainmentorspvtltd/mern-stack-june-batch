import { Route, Routes } from "react-router-dom";
import "./App.css";
import Products from "./modules/products/components/Products";
import { CarouselDemo } from "./shared/components/Carousel";
import { NavigationMenuDemo } from "./shared/components/Nav";
import Cart from "./modules/cart/components/Cart";

function App() {
  return (
    <>
      <NavigationMenuDemo />
      <CarouselDemo />
      <Routes>
        <Route path="/" element={<Products />} />
        <Route path="/cart" element={<Cart />} />
      </Routes>
    </>
  );
}

export default App;
