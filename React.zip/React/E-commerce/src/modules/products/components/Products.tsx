import { useProductStore } from "@/store/product-store";
import { useEffect } from "react";
import { ProductCard } from "./ProductCard";

const Products = () => {
  const { products, fetchProducts } = useProductStore();
  useEffect(() => {
    fetchProducts();
  }, []);
  return (
    <div className="flex justify-center items-center flex-wrap">
      {products.length > 0 &&
        products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
    </div>
  );
};

export default Products;
