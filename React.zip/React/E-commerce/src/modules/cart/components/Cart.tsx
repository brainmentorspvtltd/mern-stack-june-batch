import { useCartStore } from "@/store/cart-store";
import { CartCard } from "./CartCard";

const Cart = () => {
  const { cart } = useCartStore();
  return (
    <div className="flex flex-wrap justify-center">
      {cart.length > 0 ? (
        cart.map((product) => <CartCard key={product.id} product={product} />)
      ) : (
        <h1>Cart is Empty</h1>
      )}
    </div>
  );
};

export default Cart;
