import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, ShoppingCart, Star } from "lucide-react";
import type { IProducts } from "@/store/product-store";
import { useCartStore } from "@/store/cart-store";
interface IProductCard {
  product: IProducts;
}
export function CartCard({ product }: IProductCard) {
  const { title, description, price, discount, image } = product;
  const { deleteFromCart } = useCartStore();

  return (
    <Card className="w-full max-w-sm overflow-hidden m-4">
      {/* Product Image */}
      <div className="relative">
        <img src={image} alt="Product" className="w-full h-48 object-cover" />
        <Badge className="absolute top-2 left-2 bg-red-500 hover:bg-red-600">
          Sale
        </Badge>
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 bg-white/80 hover:bg-white"
        >
          <Heart className="h-4 w-4" />
        </Button>
      </div>

      <CardHeader className="pb-3">
        <div className="flex items-center gap-1 mb-1">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`h-4 w-4 ${
                i < 4 ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
              }`}
            />
          ))}
          <span className="text-sm text-gray-600 ml-1">(4.0)</span>
        </div>
        <CardTitle className="text-lg leading-tight">
          {title.substring(0, 10)}
        </CardTitle>
        <CardDescription className="text-sm">
          {description.substring(0, 50)}
        </CardDescription>
      </CardHeader>

      <CardContent className="pt-0">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-2xl font-bold text-green-600">
            {/* {(price * 0.8).toFixed(0)} */}
            {discount ? price - discount : price - 0}
          </span>
          <span className="text-lg text-gray-500 line-through">{price}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">
            In Stock
          </span>
          <span>Free shipping</span>
        </div>
      </CardContent>

      <CardFooter className="flex gap-2 pt-3">
        <Button onClick={() => deleteFromCart(product.id)} className="flex-1">
          <ShoppingCart className="h-4 w-4 mr-2" />
          Delete
        </Button>
      </CardFooter>
    </Card>
  );
}
