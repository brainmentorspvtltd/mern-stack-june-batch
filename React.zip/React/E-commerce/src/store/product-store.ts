import { create } from "zustand";
import axios from "axios";

export interface IProducts {
  id: number;
  title: string;
  image: string;
  price: number;
  description: string;
  brand: string;
  model: string;
  color: string;
  category: string;
  discount: number;
}

interface IProductState {
  products: IProducts[];
  fetchProducts: () => void;
}

export const useProductStore = create<IProductState>((set) => ({
  products: [],

  fetchProducts: async () => {
    const response = await axios.get("https://fakestoreapi.in/api/products");
    const data: IProducts[] = response.data.products;
    console.log(data);
    set(() => ({ products: [...data] }));
  },
}));
