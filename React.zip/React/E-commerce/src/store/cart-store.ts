import { create } from "zustand";
import type { IProducts } from "./product-store";

interface ICartState {
  cart: IProducts[];
  addToCart: (product: IProducts) => void;
  deleteFromCart: (id: number) => void;
  getProductById: (id: number) => IProducts | undefined;
  getProductIndexById: (id: number) => number;
  //   updateQuantity: (id: number) => void;
}

export const useCartStore = create<ICartState>((set, get) => ({
  cart: [],
  addToCart: (product: IProducts) => {
    console.log("Hello");
    const isExist = get().getProductById(product.id);
    if (!isExist) {
      set(() => ({ cart: [...get().cart, product] }));
    }
    console.log(get().cart);
  },
  deleteFromCart: (id: number) => {
    console.log(id);
    const isExist = get().getProductIndexById(id);
    const filtered = get().cart.filter((pro) => pro.id !== id);
    console.log(isExist);
    if (isExist != -1) {
      set(() => ({ cart: filtered }));
    }
  },
  getProductById: (id: number) => {
    return get().cart.find((product) => product.id === id);
  },
  getProductIndexById: (id: number) => {
    const productId = get().cart.findIndex((product) => product.id === id);
    console.log("Pro", productId);
    return productId;
  },
}));
