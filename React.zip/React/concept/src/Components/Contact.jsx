import { useSearchParams } from "react-router-dom"

const Contact = () => {
    const [params]= useSearchParams();
  return (
    <h1>Contact {params.get("a")}</h1>
  )
}

export default Contact