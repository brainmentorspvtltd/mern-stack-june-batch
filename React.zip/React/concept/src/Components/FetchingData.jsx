import React from 'react'
import { useState } from 'react';
import { useEffect } from 'react'

const FetchingData = () => {
    const [data , setData] = useState([]);
    useEffect(()=>{
        async function getData(){
            const response = await fetch("https://fakestoreapi.in/api/products");
            const data = await response.json();
            console.log(data.products);
            setData(data.products);
        }

        getData();
    },[]);
  return (
    <div>
        {data.length > 0 && data.map((ele)=><h1>{ele.title}</h1>)}
    </div>
  )
}

export default FetchingData