import React, { useContext } from 'react'
import { AuthContext } from '../context/AuthContext'

const Settings = () => {
    const {count , inc , dec} = useContext(AuthContext);
    
  return (
    <>
    <h1>Settings {count} </h1>
    <button onClick={inc}>+</button>
    <button onClick={dec}>-</button>
    </>
  )
}

export default Settings