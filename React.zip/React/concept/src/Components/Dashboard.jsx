import React from 'react'
import { Link, Outlet, useParams } from 'react-router-dom'

const Dashboard = () => {
    const params = useParams();
  return (
    <>
    <h1>Dashboard {params.id}</h1>
    <Link to={"/dashboard/1234/settings"}>Settings</Link>
   <Outlet/>
    </>
  )
}

export default Dashboard