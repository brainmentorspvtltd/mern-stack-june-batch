import React from 'react'
import { useRoutes } from 'react-router-dom'
import HomePage from './HomePage';
import Contact from './Contact';
import ProtectedRoute from '../Pages/ProtectedRoute';
import Dashboard from './Dashboard';
import Settings from './Settings';

const AllRoutes = () => {
  const routes = useRoutes([
    {path : "/" , element : <HomePage/>},
    {path : "/contact" , element : <Contact/>},
    {path : "/dashboard/:id" , element : <ProtectedRoute><Dashboard/></ProtectedRoute> , children:[{path : "/dashboard/:id/settings" , element : <Settings/>}]}
  ]);

  return routes;
}

export default AllRoutes