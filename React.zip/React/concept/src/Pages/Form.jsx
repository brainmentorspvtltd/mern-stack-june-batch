import { useRef } from "react";

const Form = () => {
    let name = useRef();
    let email = useRef();
    let password = useRef();
    let phone = useRef();
    function handleSubmit(e){
        e.preventDefault();
        const data = {
            name : name.current.value,
            email : email.current.value,
            password : password.current.value,
            phone : phone.current.value
        }

        console.log(data);
    }
  return (
    <div >
        <form onSubmit={handleSubmit}>
            <div className="flex flex-col ">
            <label htmlFor="#">Name</label>
        <input ref={name} type="text" className="border-2 border-black"/>
        </div>
        <div className="flex flex-col ">
            <label htmlFor="#">Phone</label>
        <input ref={phone} type="text" className="border-2 border-black"/>
        </div>

        <div className="flex flex-col ">
            <label htmlFor="#">Email</label>
        <input ref={email} type="email" className="border-2 border-black"/>
        </div>

         <div className="flex flex-col ">
            <label htmlFor="#">Password</label>
        <input ref={password} type="password" className="border-2 border-black"/>
        </div>

        <button type="submit">Submit</button>
        </form>

    </div>
  )
}

export default Form