import React from 'react'
import HomePage from '../Components/HomePage'
import About from '../Components/About'
import { Link, Route, Routes } from 'react-router-dom'
import Contact from '../Components/Contact'
import Login from '../Components/Login'
import Register from '../Components/Register'
import Dashboard from '../Components/Dashboard'
import NotFound from './NotFound'
import ProtectedRoute from './ProtectedRoute'
import Settings from '../Components/Settings'
import AllRoutes from '../Components/AllRoutes'

const RoutePage = () => {
  return (
    <>
    <div>
     
      <Link className='h-6 w-6 m-3 border-2 border-violet-500 p-3 text-amber-400 bg-blue-600' to={"/about"}>About</Link>
      <Link to={"/contact"}>Contact</Link>
      <Link to={"/login"}>Login</Link>
      <Link to={"/register"}>Register</Link>
      <Link to={"/dashboard/1234"}>Dashboard</Link>

    </div>
    {/* <Routes>
      <Route path='/' element={<HomePage/>}/>
      <Route path='/about' element={<About/>}/>
      <Route path='/contact' element={<Contact/>}/>
      <Route path='/login' element={<Login/>}/>
      <Route path='/register' element={<Register/>}/>
      <Route path='/dashboard/:id' element={<ProtectedRoute>
        <Dashboard/>
      </ProtectedRoute>}>
      <Route path='/dashboard/:id/settings' element={<Settings/>}/>
      </Route>
      <Route path='*' element={<NotFound/>}/>
      
    </Routes> */}

    <AllRoutes/>
    </>
  )
}

export default RoutePage;