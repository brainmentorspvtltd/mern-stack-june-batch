import { useState } from "react"

const ConditionalRendering = () => {
    const [isLogin , setIsLogin] = useState(false);
    // if(isLogin){
    //     return <h1>Welcome User</h1>
    // }else{
    //     return <h1>Please Login First</h1>
    // }

    return (<>
        {isLogin ? <h1>Welcome User</h1> : <h1>Please Login First</h1>}
        {isLogin && <h1>Welcome User</h1>}
        {}
    </>)
}

export default ConditionalRendering