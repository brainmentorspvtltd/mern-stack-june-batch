import { useForm } from "react-hook-form";
const ReactHookForm = () => {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();
  function onSubmit(data) {
    console.log(data);
  }
  return (
    <div>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="flex flex-col ">
          <label htmlFor="#">Name</label>
          <input
            {...register("name", {
              required: { value: true, message: "Name is Required" },
            })}
            type="text"
            className="border-2 border-black"
          />
          {errors.name && (
            <span className="text-red-600">{errors.name.message}</span>
          )}
        </div>
        <div className="flex flex-col ">
          <label htmlFor="#">Phone</label>
          <input
            {...register("phone", {
              required: { value: true, message: "Phone is Required" },
              minLength: { value: 10, message: "Min Length should be 10" },
              maxLength: { value: 10, message: "Max Length should be 10" },
              pattern: {
                value: /^[1-9]+$/i,
                message: "Please Write Numbers only",
              },
            })}
            type="text"
            className="border-2 border-black"
          />
          {errors.phone && (
            <span className="text-red-600">{errors.phone.message}</span>
          )}
        </div>

        <div className="flex flex-col ">
          <label htmlFor="#">Email</label>
          <input
            {...register("email", {
              required: { value: true, message: "Email is Required" },
            })}
            type="email"
            className="border-2 border-black"
          />
          {errors.email && (
            <span className="text-red-600">{errors.email.message}</span>
          )}
        </div>

        <div className="flex flex-col ">
          <label htmlFor="#">Password</label>
          <input
            {...register("password", {
              required: { value: true, message: "Password is Required" },
              pattern: {
                value: /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+]).{8,}$/,
                message: "Password is Not Valid",
              },
            })}
            type="password"
            className="border-2 border-black"
          />
          {errors.password && (
            <span className="text-red-600">{errors.password.message}</span>
          )}
        </div>

        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default ReactHookForm;
