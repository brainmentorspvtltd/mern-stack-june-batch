import { useState } from "react"

const IterativeRendering = () => {
    const [names , setNames] = useState(["Yash" , "Akshit" , "Ayush" , "Aryan" ,"Nikita"]);
  return (
    <div>

        {names.map((name , index)=><h1 key={index}>{name}</h1>)}
    </div>
  )
}

export default IterativeRendering