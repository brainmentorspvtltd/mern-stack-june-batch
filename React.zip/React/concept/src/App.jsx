import React from 'react'
import './App.css'
import ConditionalRendering from './Pages/ConditionalRendering'
import IterativeRendering from './Pages/IterativeRendering'

function App() {
  

  return (
    <>
    {/* {React.createElement('h1' , "Please Login First")} */}
      {/* <ConditionalRendering/> */}
      <IterativeRendering/>
    
    </>
  )
}

export default App
