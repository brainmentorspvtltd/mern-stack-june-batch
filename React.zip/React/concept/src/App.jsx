import React, { useState } from 'react'
import './App.css'
import ConditionalRendering from './Pages/ConditionalRendering'
import IterativeRendering from './Pages/IterativeRendering'

import RoutePage from './Pages/RoutePage'
import { AuthContext } from './context/AuthContext'

function App() {
  
  const [count , setCount] = useState(0);
  function inc(){
    setCount(count + 1);
  }

  function dec(){
    setCount(count - 1);
  }
  return (
    <>
    {/* {React.createElement('h1' , "Please Login First")} */}
      {/* <ConditionalRendering/> */}
      {/* <IterativeRendering/> */}
     <AuthContext.Provider value={{count , inc , dec}}>
       <RoutePage/>
     </AuthContext.Provider>
    
    </>
  )
}

export default App
