import { useState } from "react";
import Button from "../components/Button";
import Message from "../components/Message";

export function CounterPage(){
    const [count , setCount] = useState(0);
    const inc = ()=>{
        setCount(count + 1);
        console.log(count);
    }

    const dec = ()=>{
        setCount(count - 1);
        console.log(count);
    }

    return (<>
        <Message text={count}/>
        <Button text="+" fn={inc}/>
        <Button text="-" fn={dec}/>
    </>)
}