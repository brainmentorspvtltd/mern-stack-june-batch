
const Button = (props) => {
  return (
    <button onClick={props.fn}>{props.text}</button>
  )
}

export default Button