import { create } from "zustand";

const useCountStore = create((set) => ({
  count: 0,
  data: [],
  inc: () =>
    set((state) => ({
      count: state.count + 1,
    })),
  dec: () =>
    set((state) => ({
      count: state.count - 1,
    })),

  fetchData: async () => {
    const response = await fetch("https://fakestoreapi.in/api/products");
    const data = await response.json();
    console.log(data);
    set(() => ({
      data: data.products,
    }));
  },
}));

export default useCountStore;
