import './App.css'
import CounterPage from './pages/CounterPage'

function App() {
  console.log("Hello");
  return (
    <>
      <CounterPage/>
    </>
  )
}

export default App
