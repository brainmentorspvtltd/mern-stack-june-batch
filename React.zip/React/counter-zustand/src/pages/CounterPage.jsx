import { useEffect } from "react"
import Button from "../components/Button"
import Message from "../components/Message"
import useCountStore from "../store/CountStore"

const CounterPage = () => {
    const {fetchData , data} = useCountStore(); 
    useEffect(()=>{
        fetchData();
    }, []);

    console.log("Data is" , data)
  return (
    <div>

        <Message/>
        <Button text={"-"}/>
        <Button text={"+"}/>
        {data.length > 0 &&  data.map((ele)=> <h1>{ele.title}</h1>)}
    </div>
  )
}

export default CounterPage