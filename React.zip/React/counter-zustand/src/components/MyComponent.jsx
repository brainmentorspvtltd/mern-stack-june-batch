const MyComponent = () => {
  return (
    <>
      <h1>I am Lazy Loaded Component</h1>
    </>
  );
};

export default MyComponent;
