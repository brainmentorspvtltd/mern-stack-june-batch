import useCountStore from "../store/CountStore"

const Button = ({text}) => {
    const {inc , dec} = useCountStore();
  return (
    <button onClick={text == "-" ? dec : inc}>{text}</button>
  )
}

export default Button