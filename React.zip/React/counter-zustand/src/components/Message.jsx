import useCountStore from "../store/CountStore"

const Message = () => {
    const {count} = useCountStore();
  return (
    <div>{count}</div>
  )
}

export default Message;