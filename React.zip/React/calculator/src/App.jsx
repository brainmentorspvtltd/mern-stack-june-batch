
import './App.css'
import CalcPage from './pages/CalcPage';

function App() {
  const myStyle = {color : "violet"};
  return (
   <>
    <CalcPage/>
   </>
  )
}

export default App
