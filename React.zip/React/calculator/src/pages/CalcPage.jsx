import { useState } from "react";
import Input from "../components/Input";
import Button from "../components/Button";

const CalcPage = () => {

    const [expression , setExpression] = useState("");

    function takeInput(text){
        setExpression(expression + text);
    }

    function evaluate(){
        const exp =  expression.replace(/\b0+(\d)/g , "$1");
        setExpression(eval(exp));
    }
    function allClear(){
        setExpression("");
    }
    
    return (
    <>

    <h1 className="bg-blue-600">Calc</h1>
        <Input expression={expression}/>

         <div className="btns">
            <Button text={"("} fn={takeInput}/>
            <Button text={")"} fn={takeInput}/>
            <Button text={"%"} fn={takeInput}/>
            <Button text={"AC"} fn={allClear}/>
         </div>
         <div className="btns">
            <Button text={"7"} fn={takeInput}/>
            <Button text={"8"} fn={takeInput}/>
            <Button text={"9"} fn={takeInput}/>
            <Button text={"/"} fn={takeInput}/>
         </div>
         <div className="btns">
            <Button text={"4"} fn={takeInput}/>
            <Button text={"5"} fn={takeInput}/>
            <Button text={"6"} fn={takeInput}/>
            <Button text={"*"} fn={takeInput}/>
         </div>
         <div className="btns">
            <Button text={"1"} fn={takeInput}/>
            <Button text={"2"} fn={takeInput}/>
            <Button text={"3"} fn={takeInput}/>
            <Button text={"-"} fn={takeInput}/>
         </div>
         <div className="btns">
            <Button text={"0"} fn={takeInput}/>
            <Button text={"."} fn={takeInput}/>
            <Button text={"="} fn={evaluate}/>
            <Button text={"+"} fn={takeInput}/>
         </div>
    </>
  )
}

export default CalcPage;