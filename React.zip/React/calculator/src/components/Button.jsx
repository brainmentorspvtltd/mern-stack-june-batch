
const Button = ({text , fn}) => {
  return (
    <button className="w-20 m-[0.8px]" onClick={()=>fn(text)}>{text}</button>
  )
}

export default Button