
const Input = ({expression}) => {
  return (
    <input className="h-11 w-full border-3 border-black mt-3 mb-3 rounded-md text-2xl font-bold" type="text" defaultValue={expression} />
  )
}

export default Input;