import { useCartStore } from "@/store/cart-store";
import { CartCard } from "./CartCard";
import { useEffect } from "react";

const Cart = () => {
  const { cart, getCartByUserId } = useCartStore();
  useEffect(() => {
    getCartByUserId();
  }, []);
  console.log("Cart Array is", cart);
  return (
    <div className="flex flex-wrap justify-center">
      {cart.length > 0 ? (
        cart.map((product) => <CartCard key={product.id} product={product} />)
      ) : (
        <h1>Cart is Empty</h1>
      )}
    </div>
  );
};

export default Cart;
