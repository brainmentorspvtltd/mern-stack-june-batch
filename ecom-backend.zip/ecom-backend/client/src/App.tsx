import { Route, Routes } from "react-router-dom";
import "./App.css";
import Products from "./modules/products/components/Products";
import { CarouselDemo } from "./shared/components/Carousel";
import { NavigationMenuDemo } from "./shared/components/Nav";
import Cart from "./modules/cart/components/Cart";
import RegisterPage from "./modules/auth/components/Register";
import LoginForm from "./modules/auth/components/Login";
import ProtectedRoute from "./shared/components/ProtectedRoute";
import { useAuthStore } from "./store/auth-store";

function App() {
  const { user } = useAuthStore();
  console.log("Use r is ", user);
  return (
    <>
      <NavigationMenuDemo />
      {/* <CarouselDemo /> */}
      <Routes>
        <Route path="/" element={<Products />} />
        <Route
          path="/cart"
          element={
            <ProtectedRoute>
              <Cart />
            </ProtectedRoute>
          }
        />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/login" element={<LoginForm />} />
      </Routes>
    </>
  );
}

export default App;
