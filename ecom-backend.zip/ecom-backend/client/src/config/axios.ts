import axios from "axios";

export const api = axios.create({
  baseURL: "http://localhost:1234/v1", // Replace with your API base URL
});

api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("authToken"); // Or your preferred storage
    console.log(token);
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);
