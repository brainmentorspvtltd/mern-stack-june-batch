import { create } from "zustand";
import axios from "axios";

export interface IUser {
  message: string;
  data: {
    user: {
      userName: string;
    };
    token: string;
  };
}

interface IUserState {
  user: IUser | null;
  login: (reqData: { email: string; password: string }) => void;
  registerUser: (reqData: {
    email: string;
    password: string;
    username: string;
  }) => void;
  logout: () => void;
}

export const useAuthStore = create<IUserState>((set) => ({
  user: null,

  login: async (reqData: { email: string; password: string }) => {
    const response = await axios.post(
      "http://localhost:1234/v1/auth/login",
      reqData
    );
    const data: IUser = response.data;
    console.log(data, "data");
    set(() => ({ user: data }));
    localStorage.setItem("authToken", data.data.token);
  },
  registerUser: async (reqData) => {
    const response = await axios.post("http://localhost:1234/v1/auth", reqData);
    const data: IUser = response.data;
    console.log(data, "data");
    set(() => ({ user: data }));
  },

  logout: () => {
    localStorage.removeItem("authToken");
  },
}));
