import { create } from "zustand";
import axios from "axios";

export interface IProducts {
  id: number;
  title: string;
  image: string;
  price: number;
  desc: string;
  brand: string;
  model?: string;
  color?: string;
  category: string;
  discount: number;
  inStock?: boolean;
}

interface IProductState {
  products: IProducts[];
  fetchProducts: () => void;
}

export const useProductStore = create<IProductState>((set) => ({
  products: [],

  fetchProducts: async () => {
    const response = await axios.get("http://localhost:1234/v1/products");
    const data: IProducts[] = response.data.data.data;
    console.log(data, "data");
    set(() => ({ products: [...data] }));
  },
}));
