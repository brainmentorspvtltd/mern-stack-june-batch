import { Navigate } from "react-router-dom";

interface IProps {
  children: React.ReactNode;
}
const ProtectedRoute = ({ children }: IProps) => {
  if (!localStorage.authToken) {
    return <Navigate to={"/login"} />;
  }
  return children;
};

export default ProtectedRoute;
