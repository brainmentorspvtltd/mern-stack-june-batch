import mongoose, { Mongoose, Schema } from "mongoose";

// id: 2,
//     title: "Microsoft Xbox...",
//     image: "https://storage...",
//     price: 57,
//     description: "Experience the modernized design of the Xbox...",
//     brand: "microsoft",
//     model: "Xbox X/S",
//     color: "white",
//     category: "gaming",
//     popular: true,
//     discount: 4

const cartItemsSchema = new mongoose.Schema({
  product_id: {
    type: String,
    ref: "Product",
    required: true,
  },
  quantity: {
    type: Number,
    default: 1,
  },

  price: {
    type: Number,
  },
});

const cartSchema = new mongoose.Schema({
  cart_id: Schema.Types.String,
  user_id: {
    type: String,
    required: true,
    ref: "users",
  },
  cart_items: [cartItemsSchema],
  cart_price: Schema.Types.String,
  is_deleted: {
    type: Boolean,
    default: false,
  },
  status: {
    type: String,
    enum: ["pending", "purchased", "abondend"],
    default: "pending",
    required: true,
  },
  total_items: Schema.Types.String,
});

export const Cart = new mongoose.model("carts", cartSchema);
