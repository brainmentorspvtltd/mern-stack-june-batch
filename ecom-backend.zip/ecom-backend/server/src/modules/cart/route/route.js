import { Router } from "express";
import {
  addToCart,
  getCartByUserId,
  removeFromCart,
} from "../controller/cart-controller.js";
import { authMiddleware } from "../../auth/middleware/auth-middleware.js";

export const cartRouter = Router();

cartRouter.get("/", authMiddleware, getCartByUserId);
cartRouter.post("/", authMiddleware, addToCart);
cartRouter.delete("/:id", authMiddleware, removeFromCart);
