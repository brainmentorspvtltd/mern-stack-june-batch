import { Response } from "../../../shared/response.js";
import { ProductResponseDTO } from "../../product/mapper/product-mapper.js";
import { cartService } from "../service/cart-service.js";

export const getCartByUserId = async (req, res) => {
  const { userId } = req.user;
  const cart = await cartService.getCartByUserId(userId);

  cart.products = cart.products.map(
    (product) => new ProductResponseDTO(product)
  );

  new Response(res, "Get Success", cart, 200);
};

export const addToCart = async (req, res) => {
  const { userId } = req.user;
  const { body } = req;
  const cart = await cartService.addToCart(userId, body.productId);
  new Response(res, "Add Success", cart, 201);
};

export const removeFromCart = async (req, res) => {
  const { userId } = req.user;
  const { id } = req.params;
  const cart = await cartService.removeFromCart(userId, id);
  new Response(res, "Remove Success", cart, 201);
};
