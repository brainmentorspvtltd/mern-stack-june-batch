import { Cart } from "../../../db/schema/Cart.js";
import { v4 as uuidv4 } from "uuid";
import { productService } from "../../product/service/product-service.js";
import { ProductResponseDTO } from "../../product/mapper/product-mapper.js";

export const cartService = {
  async getCartByUserId(id) {
    const cart = await Cart.aggregate([
      {
        $match: {
          user_id: id,
          is_deleted: false,
        },
      },
      {
        $sort: {
          _id: -1,
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "user_id",
          foreignField: "user_id",
          as: "user_detail",
        },
      },
      {
        $lookup: {
          from: "products",
          localField: "cart_items.product_id",
          foreignField: "product_id",
          as: "products",
        },
      },

      {
        $project: {
          cart_id: 1,
          user_id: 1,
          cart_items: 1,
          cart_price: 1,
          total_items: 1,
          status: 1,
          createdAt: 1,
          updatedAt: 1,
          user_detail: 1,
          products: 1,
        },
      },
    ]);

    console.log("Data before sending", cart.products);

    return cart.length > 0 ? cart[0] : null;
  },

  async addToCart(userId, productId) {
    let cart = await this.getCartByUserId(userId);
    const product = await productService.getProductByProductId(productId);

    if (!cart) {
      const cartId = uuidv4();

      cart = new Cart({
        user_id: userId,
        cart_id: cartId,
        cart_items: [
          {
            product_id: productId,
            quantity: 1,
            price: Number(product.product_price),
          },
        ],
        isDeleted: false,
        cart_price: Number(product.product_price),
        status: "pending",
        total_items: 1,
      });

      await cart.save();
    } else {
      const productIndex = cart.cart_items.findIndex(
        (product) => product.product_id === productId
      );

      if (productIndex === -1) {
        cart.cart_items.push({
          product_id: productId,
          quantity: 1,
          price: Number(product.product_price),
        });
      } else {
        cart.cart_items[productIndex].quantity += 1;
      }

      cart.total_items = cart.cart_items.reduce(
        (total, item) => total + item.quantity,
        0
      );

      cart.cart_price = cart.cart_items.reduce(
        (total, item) => total + item.quantity * Number(item.price),
        0
      );
    }

    console.log("The final cart is  here", cart.products);
    cart.products = cart.products.map(
      (product) => new ProductResponseDTO(product)
    );

    if (cart._id) {
      await Cart.findByIdAndUpdate(cart._id, {
        cart_items: cart.cart_items,
        total_items: cart.total_items,
        cart_price: cart.cart_price,
      });
    }

    return cart;
  },

  async removeFromCart(userId, productId) {
    try {
      let cart = await Cart.findOne({
        user_id: userId,
        is_deleted: false,
        status: "pending",
      });

      if (!cart) {
        throw new Error("Cart not found");
      }

      const productIndex = cart.cart_items.findIndex(
        (item) => item.product_id === productId
      );

      if (productIndex === -1) {
        throw new Error("Product not found in cart");
      }

      // Remove the item from cart
      cart.cart_items.splice(productIndex, 1);

      await cart.save();
      console.log("Deleted", cart);
      cart = await this.getCartByUserId(userId);
      cart.products = cart.products.map(
        (product) => new ProductResponseDTO(product)
      );
      return cart;
    } catch (error) {
      console.error("Error in removeFromCart:", error);
      throw error;
    }
  },

  async updateCartItemQuantity(userId, productId, quantity) {
    try {
      const cart = await Cart.findOne({
        user_id: userId,
        is_deleted: false,
        status: "pending",
      });

      if (!cart) {
        throw new Error("Cart not found");
      }

      const productIndex = cart.cart_items.findIndex(
        (item) => item.product_id === productId
      );

      if (productIndex === -1) {
        throw new Error("Product not found in cart");
      }

      if (quantity <= 0) {
        // Remove item if quantity is 0 or negative
        cart.cart_items.splice(productIndex, 1);
      } else {
        // Update quantity
        cart.cart_items[productIndex].quantity = quantity;
      }

      await cart.save();
      return cart;
    } catch (error) {
      console.error("Error in updateCartItemQuantity:", error);
      throw error;
    }
  },

  async decreaseQuantity(userId, productId) {
    try {
      const cart = await Cart.findOne({
        user_id: userId,
        is_deleted: false,
        status: "pending",
      });

      if (!cart) {
        throw new Error("Cart not found");
      }

      const productIndex = cart.cart_items.findIndex(
        (item) => item.product_id === productId
      );

      if (productIndex === -1) {
        throw new Error("Product not found in cart");
      }

      // Decrease quantity
      cart.cart_items[productIndex].quantity -= 1;

      // If quantity becomes 0 or less, remove the item
      if (cart.cart_items[productIndex].quantity <= 0) {
        cart.cart_items.splice(productIndex, 1);
      }

      await cart.save();
      return cart;
    } catch (error) {
      console.error("Error in decreaseQuantity:", error);
      throw error;
    }
  },

  async clearCart(userId) {
    try {
      const cart = await Cart.findOne({
        user_id: userId,
        is_deleted: false,
        status: "pending",
      });

      if (!cart) {
        throw new Error("Cart not found");
      }

      cart.cart_items = [];
      await cart.save();
      return cart;
    } catch (error) {
      console.error("Error in clearCart:", error);
      throw error;
    }
  },

  async getCartItemCount(userId) {
    try {
      const cart = await Cart.findOne({
        user_id: userId,
        is_deleted: false,
        status: "pending",
      });

      if (!cart) {
        return 0;
      }

      return cart.total_items || 0;
    } catch (error) {
      console.error("Error in getCartItemCount:", error);
      return 0;
    }
  },

  async markCartAsPurchased(userId, cartId) {
    try {
      const cart = await Cart.findOne({
        user_id: userId,
        cart_id: cartId,
        is_deleted: false,
        status: "pending",
      });

      if (!cart) {
        throw new Error("Cart not found");
      }

      cart.status = "purchased";
      await cart.save();
      return cart;
    } catch (error) {
      console.error("Error in markCartAsPurchased:", error);
      throw error;
    }
  },

  async markCartAsAbandoned(userId, cartId) {
    try {
      const cart = await Cart.findOne({
        user_id: userId,
        cart_id: cartId,
        is_deleted: false,
        status: "pending",
      });

      if (!cart) {
        throw new Error("Cart not found");
      }

      cart.status = "abandoned";
      await cart.save();
      return cart;
    } catch (error) {
      console.error("Error in markCartAsAbandoned:", error);
      throw error;
    }
  },
};
