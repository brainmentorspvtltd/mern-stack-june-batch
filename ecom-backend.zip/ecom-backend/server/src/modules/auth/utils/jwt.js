import jwt from "jsonwebtoken";

const generateToken = (userId) => {
  try {
    const token = jwt.sign({ userId: userId }, process.env.JWT_SECRET, {
      expiresIn: "2h",
    });
    return token;
  } catch (err) {
    throw new Error("Error in token Generation");
  }
};

const verifyToken = (token) => {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    return decoded;
  } catch (err) {
    console.log(err);
    throw new Error("Error in token Verification");
  }
};

export { generateToken, verifyToken };
