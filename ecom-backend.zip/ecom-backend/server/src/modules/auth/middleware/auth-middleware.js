import { verifyToken } from "../../auth/utils/jwt.js";

export const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization;
  console.log("My token", token);
  if (!token && !token.startsWith("Bearer")) {
    res.status(501).json({ message: "Token in Not Valid" });
  }

  const actualToken = token.split(" ")[1];

  const decoded = verifyToken(actualToken);
  if (!decoded) {
    res.status(501).json({ message: "User Not Verified" });
  }
  req.user = decoded;
  next();
};
