import { User } from "../../../db/schema/User.js";
import { logger } from "../../../logger/logger.js";
import { AppError } from "../../../shared/AppError.js";
import { hashPassword } from "../utils/hash-password.js";
import { v4 as uuidv4 } from "uuid";

export const authService = {
  async register(value, res) {
    try {
      const userId = uuidv4();

      const isExisting = await User.findOne({ email: value.email });

      if (isExisting) {
        logger.error("User already Exists ");
        throw new AppError(res, "User already exists", 501);
      }
      const hashedPassword = hashPassword(value.password);
      console.log("yha bhi aaya");
      const user = new User({
        user_id: userId,
        user_name: value.username,
        role: value.role,
        password: hashedPassword,
        email: value.email,
        phone: value.phone,
      });
      console.log("aur neeche bhi aaya", user);
      await user.save();

      logger.info(`User Created Successfully with id ${userId}`);

      return user;
    } catch (err) {
      throw new AppError(res, "Some error", 501);
    }
  },
  login() {},

  logout() {},
  getUSerById() {},
};
