import { User } from "../../../db/schema/User.js";
import { logger } from "../../../logger/logger.js";
import { AppError } from "../../../shared/AppError.js";
import { Response } from "../../../shared/response.js";
import { authService } from "../service/auth-service.js";
import { comaprePassword, hashPassword } from "../utils/hash-password.js";
import { generateToken } from "../utils/jwt.js";
import { loginSchema } from "../validator/loginValidator.js";
import { registerSchema } from "../validator/registerValidator.js";

const login = async (req, res) => {
  const body = req.body;
  const { error, value } = loginSchema.validate(body);
  const { email } = value;

  const user = await User.findOne({ email });

  if (!user) {
    throw new AppError(res, "User Not Found");
  }
  const paswordMatched = comaprePassword(value.password, user.password);
  if (!paswordMatched) {
    throw new AppError(res, "Invalid Password");
  }

  const token = generateToken(user.user_id);

  new Response(
    res,
    "Login Succesfull",
    { user: { userName: user.user_name }, token: token },
    201
  );
};

const logout = (req, res) => {};

const register = async (req, res) => {
  try {
    const body = req.body;
    console.log(body);
    const { error, value } = registerSchema.validate(body);

    const user = await authService.register(value, res);
    new Response(res, "User Registeres", user, 201);
  } catch (err) {
    logger.error("Error in SignUp", err);
  }
};

const getUserByUserId = (req, res) => {};

const getAllUsers = (req, res) => {};

const updateUser = (req, res) => {};

const deleteUser = (req, res) => {};

export {
  getAllUsers,
  login,
  register,
  updateUser,
  deleteUser,
  getUserByUserId,
  logout,
};
