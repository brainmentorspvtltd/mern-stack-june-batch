import { Product } from "../../../db/schema/Product.js";
import { ProductResponseDTO } from "../mapper/product-mapper.js";

export const productService = {
  async getProductByProductId(id) {
    console.log(id);
    const product = await Product.findOne({ product_id: id });
    if (!product) {
      throw new Error("Product not Found");
    }
    return product;
  },

  async getAllProducts() {
    let products = await Product.find();
    products = products.map((product) => new ProductResponseDTO(product));
    if (products.length === 0) {
      throw new Error("Product not Found");
    }
    return products;
  },
};
