export class ProductResponseDTO {
  constructor(product) {
    this.id = product.product_id;
    this.title = product.product_title;
    this.desc = product.product_description;
    this.brand = product.product_brand;
    this.price = product.product_price;
    this.discount = product.product_discounted_price;
    this.image = product.product_image;
    this.category = product.product_category;
    this.inStock = product.product_instock;
  }
}
