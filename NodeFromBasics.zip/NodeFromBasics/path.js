import path from "node:path";
import http from "node:http";

const url = "hello/hi/yash";

const newPath = path.join(url, "abcd");
console.log(newPath);
path.dirname("/foo/bar/baz/asdf/quux");

const server = http.createServer((req, res) => {
  if (req.url === "/") {
    res.write("Hello server");
    res.end();
  } else if (req.url === "/about") {
    res.end("Hello I am About");
  }
});

server.listen(1234, () => {
  console.log("Server is Running");
});
