import { User } from "../../../db/schema/User.js";

export const checkRole = (...allowedRoles) => {
  return async (req, res, next) => {
    const userId = req.user.userId;
    const user = await User.findOne({ user_id: userId });
    if (!allowedRoles.includes(user.role)) {
      res.status(501).json({ message: "Access Denied" });
    }
    next();
  };
};
