import { User } from "../../../db/schema/User.js";
import { logger } from "../../../logger/logger.js";
import { AppError } from "../../../shared/AppError.js";
import { Response } from "../../../shared/response.js";
import { comaprePassword, hashPassword } from "../utils/hash-password.js";
import { generateToken } from "../utils/jwt.js";
import { loginSchema } from "../validator/loginValidator.js";
import { registerSchema } from "../validator/registerValidator.js";
import { v4 as uuidv4 } from "uuid";

const login = async (req, res) => {
  const body = req.body;
  const { error, value } = loginSchema.validate(body);
  const { email } = value;

  const user = await User.findOne({ email });

  if (!user) {
    throw new AppError(res, "User Not Found");
  }
  const paswordMatched = comaprePassword(value.password, user.password);
  if (!paswordMatched) {
    throw new AppError(res, "Invalid Password");
  }

  const token = generateToken(user.user_id);

  new Response(
    res,
    "Login Succesfull",
    { user: { userName: user.user_name }, token: token },
    201
  );
};

const logout = (req, res) => {};

const register = async (req, res) => {
  try {
    const body = req.body;
    console.log(body);
    const { error, value } = registerSchema.validate(body);
    console.log(value);
    const userId = uuidv4();
    const isExisting = await User.findOne({ email: req.body.email });

    if (isExisting) {
      logger.error("User already Exists ");
      throw new Error("User already exists");
    }
    const hashedPassword = hashPassword(value.password);
    const user = new User({
      user_id: userId,
      user_name: value.username,
      role: value.role,
      password: hashedPassword,
      email: value.email,
      phone: value.phone,
    });
    await user.save();
    logger.info(`User Created Successfully with id ${userId}`);
    res.status(201).json({ user: user });
  } catch (err) {
    logger.error("Error in SignUp", err);
  }
};

const getUserByUserId = (req, res) => {};

const getAllUsers = (req, res) => {};

const updateUser = (req, res) => {};

const deleteUser = (req, res) => {};

export {
  getAllUsers,
  login,
  register,
  updateUser,
  deleteUser,
  getUserByUserId,
  logout,
};
