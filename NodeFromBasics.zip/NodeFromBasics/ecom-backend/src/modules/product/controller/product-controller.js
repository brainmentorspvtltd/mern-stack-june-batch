const getAllProducts = (req, res) => {};

const addProduct = (req, res) => {};

const deleteProduct = (req, res) => {};

const updatePrice = (req, res) => {};

const getProductById = (req, res) => {};

const getProductByCategory = () => {};

const filterByPrice = () => {};

const searchProductByTitle = () => {};

const updateProduct = () => {};

export {
  getAllProducts,
  addProduct,
  deleteProduct,
  updatePrice,
  getProductById,
  getProductByCategory,
  filterByPrice,
  searchProductByTitle,
  updateProduct,
};
