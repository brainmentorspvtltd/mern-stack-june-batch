import { Product } from "../../../db/schema/Product.js";
import { Response } from "../../../shared/response.js";
import { v4 as uuidv4 } from "uuid";
import { productSchema } from "../validator/product-validator.js";

const getAllProducts = (req, res) => {};

const addProduct = async (req, res) => {
  const body = req.body;
  const { error, value } = productSchema.validate(body);
  
  const productId = uuidv4();

  const product = new Product({
    product_id: productId,
    product_title: value.title,
    product_description: value.description,
    product_image: value.image,
    product_price: value.price,
    product_brand: value.brand,
    product_discounted_price: value.discountedPrice,
    product_instock: true,
    product_category: value.category,
  });

  await product.save();

  new Response(res, "Product Added SuccessFully", { product }, 201);
};

const deleteProduct = (req, res) => {};

const updatePrice = (req, res) => {};

const getProductById = (req, res) => {};

const getProductByCategory = () => {};

const filterByPrice = () => {};

const searchProductByTitle = () => {};

const updateProduct = () => {};

export {
  getAllProducts,
  addProduct,
  deleteProduct,
  updatePrice,
  getProductById,
  getProductByCategory,
  filterByPrice,
  searchProductByTitle,
  updateProduct,
};
