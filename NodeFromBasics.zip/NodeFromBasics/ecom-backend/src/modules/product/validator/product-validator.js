import Joi from "joi";

export const productSchema = Joi.object({
  title: Joi.string().min(3).alphanum().required(),
  description: Joi.string().required(),
  image: Joi.string().required(),
  price: Joi.string().required(),
  brand: Joi.string().required(),
  discountedPrice: Joi.string().required(),
  category: Joi.string().required(),
});
