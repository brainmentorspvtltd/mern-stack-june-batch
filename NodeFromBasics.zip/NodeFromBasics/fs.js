import fs from "node:fs";
// const fs = require("fs");

// fs.writeFile("text.txt", "Hello I am Yash and I am Learning Fs", (err) => {
//   if (err) {
//     console.log("Error Occurs", err);
//   } else {
//     console.log("Written Success");
//   }
// });

// try {
//   fs.writeFileSync("text.txt", "Hello I am Yash");
// } catch (err) {
//   console.log(err);
// }

// fs.readFile("text.txt", (err, data) => {
//   if (err) {
//     console.log("Error Occurs", err);
//   } else {
//     console.log(data.toString());
//   }
// });

try {
  const data = fs.readFileSync("text.txt", "utf-8");
  console.log(data);
} catch (err) {
  console.log(err);
}

fs.appendFile("text.txt", "Hello I am Yash and I am Learning Fs", (err) => {
  if (err) {
    console.log("Error Occurs", err);
  } else {
    console.log("Written Success");
  }
});

// fs.copyFile();

// console.log(__dirname);
// console.log(__filename);
