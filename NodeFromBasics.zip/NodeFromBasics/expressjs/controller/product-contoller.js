export const getData = (req, res) => {
  console.log("Request Comming");
  return res.status(200).json({
    data: [
      { title: "Shoes", price: 2000 },
      { title: "tshirt", price: 3000 },
    ],
  });
};
