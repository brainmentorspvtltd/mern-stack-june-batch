import mongoose from "mongoose";
import { User } from "../db/schema/User.js";

export const login = async (req, res) => {
  const body = req.body;

  // const user = {
  //   name : "Yash",

  // };

  const newUser = new User(body);
  await newUser.save();
  const user = await User.find();
  console.log("The Users are", user);
  if (body.name === "yash" && body.password === "123456") {
    return res.status(200).json({ data: "Hello You are logged in" });
  }
  return res.status(501).json({ message: "Invalid Credentials" });
};
