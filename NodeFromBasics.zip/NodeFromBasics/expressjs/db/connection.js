import mongoose from "mongoose";

export function createConnection() {
  const uri = process.env.MONGO_URI;
  console.log("URI IS", typeof uri);
  mongoose
    .connect(uri)
    .then((data) => console.log("COnnection Established Successfully"))
    .catch((err) => console.log("Error Occurs", err));
}
