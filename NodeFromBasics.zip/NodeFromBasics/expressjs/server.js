import express from "express";
import { authRoutes } from "./routes/routes.js";
import { productRoutes } from "./routes/product-routes.js";
import dotenv from "dotenv";
import { createConnection } from "./db/connection.js";

const app = express();
const port = 1234;
app.listen(port, () => {
  console.log(`Server is Running on port ${port}`);
});
dotenv.config();
createConnection();

app.use(express.json());
app.use("/auth", authRoutes);
app.use("/products", productRoutes);
app.get("/", (req, res) => {
  res.status(200).json({ data: "This Is Data" });
});

app.post("/", (req, res) => {
  console.log("hello");
  console.log(req.body, "body");
  res.send("Hello");
});
