import { Router } from "express";
import { getData } from "../controller/product-contoller.js";

export const productRoutes = Router();

productRoutes.get("/", getData);
