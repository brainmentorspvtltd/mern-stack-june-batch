console.log("Hello Start");

Promise.resolve().then(() => console.log("Hello I a Promise"));
process.nextTick(() => console.log("Hello I am Next tick"));
setImmediate(() => console.log("Hello I am Set Immediate"));
setTimeout(() => console.log("I am Set Timeout"));
Promise.resolve().then(() => console.log("Hello I am Promise 2"));
console.log("Hello End");
